from recognition import FaceRecognition
# pip install cmake dlib==19.22

if __name__ == '__main__':
    fr = FaceRecognition()
    fr.run_recognition()
